package fr.eni.ecole.demospringbeanapplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import fr.eni.ecole.demospringbeanapplication.bo.Trainer;
import fr.eni.ecole.demospringbeanapplication.dao.TrainerDAO;

//@Service
//@Primary
//@Profile("default")
public class TrainerServiceImpl implements TrainerService{

	private TrainerDAO trainerDAO;
	
	@Autowired
	public TrainerServiceImpl(TrainerDAO trainerDAO) {
		this.trainerDAO=trainerDAO;
	}
	
	@Override
	public void add(String firstName, String lastName, String email) {
		Trainer trainer = new Trainer(firstName,lastName,email);
		trainerDAO.create(trainer);
		
	}

	@Override
	public List<Trainer> findAll() {
		return trainerDAO.findAll();
	}

}
