/**
 * 
 */
package fr.eni.ecole.demospringbeanapplication.service;

import java.util.List;

import fr.eni.ecole.demospringbeanapplication.bo.Trainer;

/**
 * @author dsanchez
 *
 */
public interface TrainerService {
	void add(String firstName, String lastName,String email);
	List<Trainer> findAll();
}
