package fr.eni.ecole.demospringbeanapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fr.eni.ecole.demospringbeanapplication.bo.Trainer;
import fr.eni.ecole.demospringbeanapplication.service.TrainerService;

@Component // ou on peut aussi utiliser @Controller puisqu'on est dans un Controller.
public class TrainerController {
	//Cette façon de faire est à éviter car ça rend les tests unitaires difficile à écrire.
	//Préférer la méthode par setter ou constructeur.
	@Autowired
	private TrainerService trainerService;
	
	
	//Utiliser l'injection par controller quand la dépendance est obligatoire et nécessairement utilisée.
	//@Autowired
//	public TrainerController(TrainerService trainerService) {
//		System.out.println("Appel du constructeur de trainerController");
//		this.trainerService=trainerService;
//	}
	
	public void showAllTrainers() {
		List<Trainer> lstTrainers=trainerService.findAll();
		System.out.println(lstTrainers);
	}
	
	
	//Utiliser l'injection par setter
	//@Autowired
	public void setTrainerService(TrainerService trainerService) {
		System.out.println("Appel de setTrainerService");
		this.trainerService=trainerService;
	}
}
