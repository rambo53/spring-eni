package fr.eni.ecole.demospringbeanapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import fr.eni.ecole.demospringbeanapplication.controller.TrainerController;

@SpringBootApplication
public class DemoSpringBeanApplication {

	public static void main(String[] args) {
		//SpringApplication.run(DemoSpringBeanApplication.class, args);
		ApplicationContext ctx=SpringApplication.run(
				DemoSpringBeanApplication.class, args);
		
		
		TrainerController trainerCtrl = ctx.getBean(TrainerController.class);
		trainerCtrl.showAllTrainers();
	}

}
