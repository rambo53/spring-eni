package fr.eni.ecole.demospringbeanapplication.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import fr.eni.ecole.demospringbeanapplication.dao.TrainerDAO;
import fr.eni.ecole.demospringbeanapplication.dao.TrainerDAOMock;
import fr.eni.ecole.demospringbeanapplication.service.TrainerService;
import fr.eni.ecole.demospringbeanapplication.service.TrainerServiceImpl;
import fr.eni.ecole.demospringbeanapplication.service.TrainerServiceMock;

@Configuration
public class AppConfiguration {
	@Bean
	public TrainerDAO getBeanTrainerDAO() {
		return new TrainerDAOMock();
	}
	
	@Bean
	@Profile("default")
	public TrainerService getBeanTrainerService() {
		return new TrainerServiceImpl(getBeanTrainerDAO());
	}
	
	@Bean
	@Profile("dev")
	public TrainerService getBeanTrainerServiceMock() {
		return new TrainerServiceMock();
	}
}
