/**
 * 
 */
package fr.eni.ecole.demospringbeanapplication.dao;

import java.util.List;

import fr.eni.ecole.demospringbeanapplication.bo.Trainer;

/**
 * @author dsanchez
 *
 */
public interface TrainerDAO {
	void create(Trainer trainer);
	Trainer read(String email);
	void update(Trainer trainer);
	void delete(String email);
	List<Trainer> findAll();
	
}
