package fr.eni.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSpringBeanApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBeanApplication.class, args);
	}

}
