package fr.eni.demo.orchestre;

public class Piano {
	public void afficher() {
		System.out.println("Je suis un piano...");
	}
	public void jouer() {
		System.out.println("LA LA LA");
	}
}
