package fr.eni.demo.orchestre;

public class Violon {
	public void afficher() {
		System.out.println("Je suis un violon...");
	}
	public void jouer() {
		System.out.println("ZIN ZIN ZIN");
	}

}
