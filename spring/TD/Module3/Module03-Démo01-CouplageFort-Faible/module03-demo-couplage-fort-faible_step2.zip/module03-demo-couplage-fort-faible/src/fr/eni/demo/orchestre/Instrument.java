package fr.eni.demo.orchestre;

public interface Instrument {
	void afficher();

	void jouer();
}
